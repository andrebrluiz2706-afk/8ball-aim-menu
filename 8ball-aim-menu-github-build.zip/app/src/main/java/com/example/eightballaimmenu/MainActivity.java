package com.example.eightballaimmenu;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.ScrollView;

public class MainActivity extends Activity {
    private TableView table;
    private TextView angleValue, powerValue;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(10, 17, 31));
        getWindow().setNavigationBarColor(Color.rgb(10, 17, 31));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(12), dp(16), dp(16));
        page.setBackgroundColor(Color.rgb(10, 17, 31));

        TextView title = new TextView(this);
        title.setText("8 BALL AIM MENU");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(8), 0, dp(4));
        page.addView(title);

        TextView sub = new TextView(this);
        sub.setText("SIMULADOR DE MIRA • TREINO OFFLINE");
        sub.setTextColor(Color.rgb(90, 220, 130));
        sub.setTextSize(11);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, dp(12));
        page.addView(sub);

        table = new TableView(this);
        LinearLayout.LayoutParams tableParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        page.addView(table, tableParams);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(10), dp(14), dp(10));
        panel.setBackgroundColor(Color.rgb(22, 31, 49));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        pp.topMargin = dp(12);
        page.addView(panel, pp);

        TextView panelTitle = new TextView(this);
        panelTitle.setText("CONTROLES DE TREINO");
        panelTitle.setTextColor(Color.WHITE);
        panelTitle.setTextSize(15);
        panelTitle.setTypeface(null, Typeface.BOLD);
        panel.addView(panelTitle);

        addSwitch(panel, "Linhas coloridas", true, v -> { table.linesOn = v; table.invalidate(); });
        addSwitch(panel, "Trajetória de referência", true, v -> { table.pathOn = v; table.invalidate(); });
        addSwitch(panel, "Mostrar bolas", true, v -> { table.ballsOn = v; table.invalidate(); });

        angleValue = addSlider(panel, "Ângulo", 0, 360, 35, v -> {
            angleValue.setText("Ângulo: " + v + "°");
            table.angle = v;
            table.invalidate();
        });
        powerValue = addSlider(panel, "Força", 1, 100, 65, v -> {
            powerValue.setText("Força: " + v + "%");
            table.power = v;
            table.invalidate();
        });

        TextView note = new TextView(this);
        note.setText("Este app é um simulador independente. Não se conecta nem altera o 8 Ball Pool.");
        note.setTextColor(Color.rgb(170, 182, 201));
        note.setTextSize(11);
        note.setGravity(Gravity.CENTER);
        note.setPadding(dp(4), dp(10), dp(4), 0);
        panel.addView(note);

        ScrollView scroll = new ScrollView(this);
        // Put the controls in a compact scroll area on smaller phones.
        page.removeView(panel);
        scroll.addView(panel);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(290));
        sp.topMargin = dp(12);
        page.addView(scroll, sp);

        setContentView(page);
    }

    private interface Toggle { void changed(boolean value); }
    private void addSwitch(LinearLayout parent, String label, boolean checked, Toggle cb) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextColor(Color.WHITE);
        s.setTextSize(13);
        s.setChecked(checked);
        s.setPadding(0, dp(4), 0, dp(4));
        s.setOnCheckedChangeListener((b, v) -> cb.changed(v));
        parent.addView(s);
    }

    private interface Slide { void changed(int value); }
    private TextView addSlider(LinearLayout parent, String label, int min, int max, int initial, Slide cb) {
        TextView value = new TextView(this);
        value.setText(label + ": " + initial + (label.equals("Força") ? "%" : "°"));
        value.setTextColor(Color.WHITE);
        value.setTextSize(13);
        parent.addView(value);
        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(initial - min);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean u) { cb.changed(p + min); }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });
        parent.addView(bar);
        return value;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
