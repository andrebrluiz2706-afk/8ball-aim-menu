package com.example.eightballaimmenu;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

public class TableView extends View {
    final Paint p = new Paint(3);
    boolean linesOn = true, pathOn = true, ballsOn = true;
    int angle = 35, power = 65;

    public TableView(Context c) { super(c); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        c.drawColor(Color.rgb(10,17,31));
        float l=w*.035f, t=h*.08f, r=w*.965f, b=h*.92f;
        p.setColor(Color.rgb(110,38,27)); p.setStyle(Paint.Style.FILL);
        c.drawRoundRect(l,t,r,b,dp(22),dp(22),p);
        p.setColor(Color.rgb(0,65,92));
        c.drawRoundRect(l+dp(12),t+dp(12),r-dp(12),b-dp(12),dp(15),dp(15),p);
        p.setColor(Color.rgb(18,145,183));
        c.drawRoundRect(l+dp(25),t+dp(25),r-dp(25),b-dp(25),dp(10),dp(10),p);
        p.setColor(Color.rgb(0,105,139));
        c.drawRoundRect(l+dp(30),t+dp(30),r-dp(30),b-dp(30),dp(8),dp(8),p);

        // Pockets
        p.setColor(Color.rgb(3,7,14));
        float pr=dp(13);
        c.drawCircle(l+dp(18),t+dp(18),pr,p); c.drawCircle(w/2,t+dp(18),pr,p);
        c.drawCircle(r-dp(18),t+dp(18),pr,p); c.drawCircle(l+dp(18),b-dp(18),pr,p);
        c.drawCircle(w/2,b-dp(18),pr,p); c.drawCircle(r-dp(18),b-dp(18),pr,p);

        float cueX=l+dp(65), cueY=(t+b)/2, targetX=r-dp(95), targetY=cueY;
        if (linesOn) {
            drawLine(c,cueX,cueY,targetX,targetY,Color.WHITE,dp(2));
            drawLine(c,cueX,cueY,targetX,t+dp(65),Color.YELLOW,dp(2));
            drawLine(c,cueX,cueY,targetX,b-dp(65),Color.CYAN,dp(2));
            drawLine(c,cueX,cueY,l+dp(20),t+dp(100),Color.RED,dp(2));
            drawLine(c,cueX,cueY,l+dp(20),b-dp(100),Color.GREEN,dp(2));
        }
        if (pathOn) {
            double a=Math.toRadians(angle);
            float len=dp(150)*(power/65f);
            Path path=new Path();
            path.moveTo(cueX,cueY);
            path.lineTo(cueX+(float)Math.cos(a)*len,cueY-(float)Math.sin(a)*len);
            p.setColor(Color.rgb(255,145,35)); p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(3)); p.setStrokeCap(Paint.Cap.ROUND);
            c.drawPath(path,p); p.setStyle(Paint.Style.FILL);
        }
        if (ballsOn) {
            float bx=w*.72f, by=h*.5f, rr=dp(10);
            int[] colors={Color.WHITE,Color.YELLOW,Color.RED,Color.BLUE,Color.GREEN,Color.MAGENTA,Color.rgb(255,145,20),Color.BLACK};
            for(int i=0;i<8;i++){
                float x=bx+(i%3)*rr*1.55f, y=by+(i/3)*rr*1.65f;
                p.setColor(colors[i]); c.drawCircle(x,y,rr,p);
                p.setColor(Color.WHITE); c.drawCircle(x,y,rr*.42f,p);
                p.setColor(Color.DKGRAY); p.setTextSize(rr*.55f); p.setTextAlign(Paint.Align.CENTER);
                c.drawText(""+(i+1),x,y+rr*.2f,p);
            }
            p.setColor(Color.WHITE); c.drawCircle(cueX,cueY,rr,p);
            p.setColor(Color.LTGRAY); c.drawCircle(cueX-rr*.25f,cueY-rr*.25f,rr*.25f,p);
        }
        p.setColor(Color.WHITE); p.setTextSize(dp(12)); p.setTextAlign(Paint.Align.CENTER);
        c.drawText("MESA DE TREINO",w/2,h-dp(8),p);
    }
    private void drawLine(Canvas c,float x1,float y1,float x2,float y2,int color,float sw){
        p.setColor(color); p.setStrokeWidth(sw); p.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(x1,y1,x2,y2,p);
        p.setStyle(Paint.Style.FILL); c.drawCircle(x2,y2,dp(4),p);
    }
    private float dp(float v){return v*getResources().getDisplayMetrics().density;}
}
