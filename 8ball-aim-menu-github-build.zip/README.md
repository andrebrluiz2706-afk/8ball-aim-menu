# 8 BALL AIM MENU — Android

Protótipo Android independente para treino visual de bilhar.

## Gerar APK pelo GitHub (sem Android Studio)
1. No GitHub, crie um repositório novo, por exemplo `8ball-aim-menu`.
2. Envie todos os arquivos deste projeto para o repositório, mantendo a pasta `.github/workflows`.
3. Abra a aba **Actions** e habilite GitHub Actions, se solicitado.
4. Selecione **Build Android APK** e toque em **Run workflow**. Um push na branch `main` também inicia a compilação.
5. Quando a execução terminar com sucesso, abra-a e baixe o artefato **8ball-aim-menu-debug-apk**.
6. Extraia o artefato e instale `app-debug.apk` no Android. Autorize a instalação pelo navegador/arquivos se o Android solicitar.

Não precisa instalar Android Studio no telefone.

## Limites
Este é um simulador offline independente. Não lê a tela, não injeta código, não automatiza tacadas e não modifica o 8 Ball Pool.
